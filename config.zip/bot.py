from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler
from config import TOKEN, IBAN, ADMIN_ID
import logging

logging.basicConfig(level=logging.INFO)

ASK_NAME, ASK_LANGUAGE, ASK_TYPE, ASK_PURPOSE, ASK_SCREENSHOT = range(5)
LANGUAGES = ["Русский", "Deutsch", "English"]
TYPES = ["Резюме", "Мотивационное письмо"]
PURPOSES = ["Работа", "Учёба", "Виза"]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я помогу тебе создать резюме или мотивационное письмо. Как тебя зовут?")
    return ASK_NAME

async def ask_language(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["name"] = update.message.text
    reply = ReplyKeyboardMarkup([LANGUAGES], one_time_keyboard=True)
    await update.message.reply_text("Выбери язык:", reply_markup=reply)
    return ASK_LANGUAGE

async def ask_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["language"] = update.message.text
    reply = ReplyKeyboardMarkup([TYPES], one_time_keyboard=True)
    await update.message.reply_text("Что ты хочешь заказать?", reply_markup=reply)
    return ASK_TYPE

async def ask_purpose(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["type"] = update.message.text
    reply = ReplyKeyboardMarkup([PURPOSES], one_time_keyboard=True)
    await update.message.reply_text("Для какой цели нужно?", reply_markup=reply)
    return ASK_PURPOSE

async def ask_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["purpose"] = update.message.text
    await update.message.reply_text(f"Отлично! Теперь переведи 39€ на IBAN:

{IBAN}

После оплаты пришли скриншот как подтверждение.")
    return ASK_SCREENSHOT

async def receive_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["screenshot"] = update.message.photo[-1].file_id
    summary = (
        "Новая заявка:

"
        f"Имя: {context.user_data['name']}
"
        f"Язык: {context.user_data['language']}
"
        f"Тип: {context.user_data['type']}
"
        f"Цель: {context.user_data['purpose']}

"
        "Проверь оплату и подтверди выполнение вручную."
    )
    await context.bot.send_message(chat_id=ADMIN_ID, text=summary)
    await context.bot.send_photo(chat_id=ADMIN_ID, photo=context.user_data["screenshot"])
    await update.message.reply_text("Спасибо! Ожидай ответа, мы свяжемся с тобой после подтверждения оплаты.")
    return ConversationHandler.END

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            ASK_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_language)],
            ASK_LANGUAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_type)],
            ASK_TYPE: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_purpose)],
            ASK_PURPOSE: [MessageHandler(filters.TEXT & ~filters.COMMAND, ask_screenshot)],
            ASK_SCREENSHOT: [MessageHandler(filters.PHOTO, receive_screenshot)]
        },
        fallbacks=[],
    )
    app.add_handler(conv)
    app.run_polling()

if __name__ == "__main__":
    main()
